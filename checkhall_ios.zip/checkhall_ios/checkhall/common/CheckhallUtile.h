
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>


@interface CheckhallUtile : NSObject
+ (NSString*)getIdxString:(NSString*)html;

@end
