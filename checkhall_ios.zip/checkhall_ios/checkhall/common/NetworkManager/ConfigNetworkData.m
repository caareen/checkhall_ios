//
//  ConfigNetworkData.m
//  IvoryProject
//
//  Created by Junho Jo on 12. 3. 21..
//  Copyright (c) 2012년 __MyCompanyName__. All rights reserved.
//

#import "ConfigNetworkData.h"

@implementation ConfigNetworkData
@synthesize connectURL;
@synthesize HTTPMethod;
@synthesize requestID;
@synthesize filePath;
@synthesize requestData;

- (void) dealloc {
    
}

@end
