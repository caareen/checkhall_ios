


@interface NSString (sortForIndex)

@end
