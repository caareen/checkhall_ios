//
//  NSDictionary-MutableDeepCopy.h
//  TableView_Customizing_3
//
//  Created by WooKyun Jeon on 11. 3. 11..
//  Copyright 2011 DAOU Tech. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSDictionary (MutableDeepCopy)
- (NSMutableDictionary *)mutableDeepCopy;
@end
