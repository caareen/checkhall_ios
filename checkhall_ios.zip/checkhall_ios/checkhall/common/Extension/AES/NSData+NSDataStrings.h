//
//  NSData+ NSDataStrings.h
//  SocketClient
//
//  Created by Jong Pil Park on 10. 6. 16..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSData (NSDataStrings)

- (NSString *) stringWithHexBytes;
- (NSData *) dataWithHexBytes;

@end
